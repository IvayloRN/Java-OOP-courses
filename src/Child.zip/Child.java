import java.util.Scanner;

public class Child  extends Person{
   private Person person;

    public Child(String name, int age) {
        super(name,age);
    }
}
