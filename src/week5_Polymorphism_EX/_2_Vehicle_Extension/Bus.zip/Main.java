import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] carData = getArray(scanner);
        String[] truckData = getArray(scanner);
        String[] busData = getArray(scanner);
        double busEmptyFuelConsumption = Double.parseDouble(busData[2]);
        Car car = new Car(Double.parseDouble(carData[1]) ,Double.parseDouble(carData[2]), Double.parseDouble(carData[3]));
        Truck truck = new Truck(Double.parseDouble(truckData[1]) ,Double.parseDouble(truckData[2]), Double.parseDouble(truckData[3]));
        Bus bus = new Bus(Double.parseDouble(busData[1]) ,busEmptyFuelConsumption, Double.parseDouble(busData[3]));
        if (Double.parseDouble(carData[1]) < 0 || Double.parseDouble(truckData[1]) < 0 || Double.parseDouble(busData[1]) < 0){
            System.out.println("Fuel must be a positive number");
            return;
        }

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] commands = getArray(scanner);
            String command = commands[0];
            String vehicleType = commands[1];
            double distanceOrLiters = Double.parseDouble(commands[2]);
            switch (command){
                case "Drive":
                    if (vehicleType.equals("Car")){
                        car.driving(distanceOrLiters);
                    }else if ("Truck".equals(vehicleType)) {
                        truck.driving(distanceOrLiters);
                    }else{
                        bus.setFuelConsumption(busEmptyFuelConsumption + 1.4);
                        bus.driving(distanceOrLiters);
                    }
                    break;
                case"Refuel":
                    if (vehicleType.equals("Car")){
                        car.refueling(distanceOrLiters);
                    }else if ("Truck".equals(vehicleType)){
                        truck.refueling(distanceOrLiters);
                    }else{
                        bus.refueling(distanceOrLiters);
                    }
                    break;
                case"DriveEmpty":
                    bus.setFuelConsumption(busEmptyFuelConsumption);
                    bus.driving(distanceOrLiters);
                    break;
            }
        }
        System.out.printf("Car: %.2f\n", car.getFuelQuantity());
        System.out.printf("Truck: %.2f\n", truck.getFuelQuantity());
        System.out.printf("Bus: %.2f\n", bus.getFuelQuantity());
    }
    private static String[] getArray(Scanner scanner) {
        return scanner.nextLine().split("\\s+");
    }
}
/*
Car 30 0.04 70
Truck 100 0.5 300
Bus 40 0.3 150
8
Refuels Car -10
Refuelw Truck 0
Refuel Car 10
Refuel Car 300
Drivee Bus 10
Refuel Bus 1000
DriveEmpty Bus 100
Refuel Truck 1000

* */