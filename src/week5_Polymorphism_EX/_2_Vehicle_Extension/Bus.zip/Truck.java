import java.text.DecimalFormat;
import java.util.Scanner;

public class Truck extends Vehicle{
    private final double AIR_CONDITIONER_CONSUMPTION = 1.6;
    public Truck(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity);
    }

    @Override
    public double refueling(double liters) {
        if (liters <= 0){
            System.out.println("Fuel must be a positive number");
            return getFuelQuantity();
        }
        double quantity = getFuelQuantity() + (liters * 0.95);
        if (quantity <= tankCapacity) {
            setFuelQuantity(quantity);
            return getFuelQuantity();
        }
        System.out.println("Cannot fit fuel in tank");
        return getFuelQuantity();
    }

    @Override
    public void driving(double distance) {
        double finalFuelConsumption = AIR_CONDITIONER_CONSUMPTION + fuelConsumption;
        double fuelNeeded = distance * finalFuelConsumption;
        if (getFuelQuantity() >= fuelNeeded){
            setFuelQuantity(getFuelQuantity() - fuelNeeded);
            DecimalFormat df = new DecimalFormat("#.##");
            System.out.printf("%s travelled %s km\n",getClass().getSimpleName(),df.format(distance));
        }else{
            System.out.printf("%s needs refueling\n",getClass().getSimpleName());
        }
    }
}
