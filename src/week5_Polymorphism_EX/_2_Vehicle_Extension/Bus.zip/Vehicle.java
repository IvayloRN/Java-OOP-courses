import java.text.DecimalFormat;

public abstract class Vehicle {
    protected double tankCapacity;
   private double fuelQuantity;
   protected double fuelConsumption;

    public Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
        this.tankCapacity = tankCapacity;
    }
    public double refueling(double liters){
        if (liters <= 0){
            System.out.println("Fuel must be a positive number");
            return fuelQuantity;
        }
        if (fuelQuantity + liters > tankCapacity){
            System.out.println("Cannot fit fuel in tank");
        }else{
            return fuelQuantity += liters;
        }
        return fuelQuantity;
    }
    public void driving(double distance){
        double fuelNeeded = distance * fuelConsumption;
        if (getFuelQuantity() >= fuelNeeded){
            setFuelQuantity(getFuelQuantity() - fuelNeeded);
            DecimalFormat df = new DecimalFormat("#.##");
            System.out.printf("%s travelled %s km\n",getClass().getSimpleName(),df.format(distance));
        }else{
            System.out.printf("%s needs refueling\n",getClass().getSimpleName());
        }
    }
    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public void setFuelConsumption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    public void setFuelQuantity(double fuelQuantity) {
        if (this.fuelQuantity < fuelQuantity){
            System.out.println("Fuel must be a positive number");
        }else{
            this.fuelQuantity = fuelQuantity;
        }
    }
}
//fuel quantity, and fuel consumption in liters per km