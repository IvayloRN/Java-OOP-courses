import java.util.Scanner;

public abstract class Vehicle {
   protected double fuelQuantity;
   protected double fuelConsumption;

    public Vehicle(double fuelQuantity, double fuelConsumption) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
    }
    public double refueling(double liters){

        return fuelQuantity += liters;
    }
    public void driving(double distance){

    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }
}
//fuel quantity, and fuel consumption in liters per km