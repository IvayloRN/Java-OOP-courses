import java.text.DecimalFormat;
import java.util.Scanner;

public class Car extends Vehicle{
    private final double AIR_CONDITIONER_CONSUMPTION = 0.9;
    public Car(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
    }

    @Override
    public void driving(double distance) {
        double finalFuelConsumption = AIR_CONDITIONER_CONSUMPTION + fuelConsumption;
        double fuelNeeded = distance * finalFuelConsumption;
        if (fuelQuantity >= fuelNeeded){
          fuelQuantity -= fuelNeeded;
            DecimalFormat df = new DecimalFormat("#.##");
            System.out.printf("%s travelled %s km\n",getClass().getSimpleName(),df.format(distance));
        }else{
            System.out.printf("%s needs refueling\n",getClass().getSimpleName());
        }
    }

}
//"Car/Truck travelled {distance} km"