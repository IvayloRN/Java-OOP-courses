import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] carData = getArray(scanner);
        String[] truckData = getArray(scanner);
        Car car = new Car(Double.parseDouble(carData[1]) ,Double.parseDouble(carData[2]));
        Truck truck = new Truck(Double.parseDouble(truckData[1]) ,Double.parseDouble(truckData[2]));

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] commands = getArray(scanner);
            String command = commands[0];
            String vehicleType = commands[1];
            double distanceOrLiters = Double.parseDouble(commands[2]);
            switch (command){
                case "Drive":
                    if (vehicleType.equals("Car")){
                        car.driving(distanceOrLiters);
                    }else {
                        truck.driving(distanceOrLiters);
                    }
                    break;
                case"Refuel":
                    if (vehicleType.equals("Car")){
                        car.refueling(distanceOrLiters);
                    }else{
                        truck.refueling(distanceOrLiters);
                    }
                    break;
            }
        }
        System.out.printf("Car: %.2f\n", car.getFuelQuantity());
        System.out.printf("Truck: %.2f\n", truck.getFuelQuantity());

    }

    private static String[] getArray(Scanner scanner) {
        return scanner.nextLine().split("\\s+");
    }

}
