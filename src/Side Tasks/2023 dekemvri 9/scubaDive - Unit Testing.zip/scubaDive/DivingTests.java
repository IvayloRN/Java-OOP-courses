package scubaDive;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class DivingTests {
    private Diving diving;
    private DeepWaterDiver pesho;
    private DeepWaterDiver tosho;
    private DeepWaterDiver gosho;

    @Before
    public void setUp(){
        diving = new Diving("Sharm", 4);

        pesho = new DeepWaterDiver("Pesho", 10);
        tosho = new DeepWaterDiver("Tosho", 20);
        gosho = new DeepWaterDiver("Gosho", 30);
    }



    @Test
    public void test_getCount_Should_Return_Size(){
        diving.addDeepWaterDiver(pesho);
        assertEquals(1, diving.getCount());
        diving.addDeepWaterDiver(tosho);
        assertEquals(2, diving.getCount());
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_setCapacity_Shoul_Throw_if_Capacity_is_Negative(){
        Diving diving = new Diving("Sharm", -1);
    }
    @Test(expected = NullPointerException.class)
    public void test_setName_Should_Throw_if_orEmpty(){
        Diving diving1 = new Diving("", 5);
    }
    @Test(expected = NullPointerException.class)
    public void test_setName_Should_Throw_if_Null() {
        Diving diving1 = new Diving(null, 5);
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_addDiver_Shoult_Throw_if_No_Capacity(){
        Diving diving = new Diving("Sharm", 1);
        diving.addDeepWaterDiver(pesho);
        diving.addDeepWaterDiver(tosho);
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_addDiver_Shoult_Throw_Diver_Exist(){
        diving.addDeepWaterDiver(pesho);
        diving.addDeepWaterDiver(pesho);
    }
    @Test
    public void test_removeDiver_Should_remove_diver(){
        diving.addDeepWaterDiver(pesho);
        diving.addDeepWaterDiver(gosho);
        diving.removeDeepWaterDiver("Pesho");
        assertEquals(1, diving.getCount());
    }

}





















