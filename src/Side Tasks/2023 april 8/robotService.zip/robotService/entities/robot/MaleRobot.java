package robotService.entities.robot;

import java.util.Scanner;

public class MaleRobot extends BaseRobot{           //Can only live in MainService!
    private static final int INITIAL_KILOGRAMS = 9;
    private static final int KILOGRAMS_GAIN_FROM_EATING = 3;

    public MaleRobot(String name, String kind, double price) {
        super(name, kind, INITIAL_KILOGRAMS, price);
    }

    @Override
    public void eating() {
        setKilograms(getKilograms() + KILOGRAMS_GAIN_FROM_EATING);
    }
}
