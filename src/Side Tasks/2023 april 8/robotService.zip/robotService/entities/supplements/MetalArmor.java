package robotService.entities.supplements;

import java.util.Scanner;

public class MetalArmor extends BaseSupplement{
    private static final int HARDNESS_OF_METAL = 5;
    private static final double PRICE_OF_METAL = 15;


    public MetalArmor() {
        super(HARDNESS_OF_METAL, PRICE_OF_METAL);
    }
}
