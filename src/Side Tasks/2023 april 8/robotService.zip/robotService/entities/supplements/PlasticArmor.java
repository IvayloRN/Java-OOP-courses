package robotService.entities.supplements;

import java.util.Scanner;

public class PlasticArmor extends BaseSupplement{
    private static final int HARDNESS_OF_PLASTIC = 1;
    private static final double PRICE_OF_PLASTIC = 10;

    //hardness of 1 and a price of 10
    public PlasticArmor() {
        super(HARDNESS_OF_PLASTIC, PRICE_OF_PLASTIC);
    }
}
