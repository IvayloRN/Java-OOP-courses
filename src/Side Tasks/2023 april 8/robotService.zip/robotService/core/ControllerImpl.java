package robotService.core;

import robotService.entities.robot.FemaleRobot;
import robotService.entities.robot.MaleRobot;
import robotService.entities.robot.Robot;
import robotService.entities.services.MainService;
import robotService.entities.services.SecondaryService;
import robotService.entities.services.Service;
import robotService.entities.supplements.MetalArmor;
import robotService.entities.supplements.PlasticArmor;
import robotService.entities.supplements.Supplement;
import robotService.repositories.Repository;
import robotService.repositories.SupplementRepository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;
import java.util.stream.Collectors;

import static robotService.common.ConstantMessages.*;
import static robotService.common.ExceptionMessages.*;

public class ControllerImpl implements Controller{

    private Repository supplementRepository;
    private Collection<Service> services;

    public ControllerImpl() {
        this.supplementRepository = new SupplementRepository();
        this.services = new ArrayList<>();
    }

    @Override
    public String addService(String type, String name) {
        Service service;
        switch (type){
            case"MainService":
                service = new MainService(name);
                break;
            case"SecondaryService":
                service = new SecondaryService(name);
                break;
            default:
                throw new NullPointerException(INVALID_SERVICE_TYPE);
        }
        services.add(service);

        return String.format(SUCCESSFULLY_ADDED_SERVICE_TYPE,type);
    }

    @Override
    public String addSupplement(String type) {
        Supplement supplement;
        switch (type){
            case "PlasticArmor":
                supplement = new PlasticArmor();
                break;
            case "MetalArmor":
                supplement = new MetalArmor();
                break;
            default:
                throw new IllegalArgumentException(INVALID_SUPPLEMENT_TYPE);
        }
        supplementRepository.addSupplement(supplement);

        return String.format(SUCCESSFULLY_ADDED_SUPPLEMENT_TYPE, type);
    }

    @Override
    public String supplementForService(String serviceName, String supplementType) {
        Supplement supplement = supplementRepository.findFirst(supplementType);
        if (supplement == null){
            throw new IllegalArgumentException(String.format(NO_SUPPLEMENT_FOUND, supplementType));
        }
        Service service = services.stream()
                .filter(s-> s.getName()
                .equals(serviceName))
                .findFirst().orElse(null);
        service.addSupplement(supplement);
        supplementRepository.removeSupplement(supplement);
        return String.format(SUCCESSFULLY_ADDED_SUPPLEMENT_IN_SERVICE, supplementType, serviceName);
    }

    @Override
    public String addRobot(String serviceName, String robotType, String robotName, String robotKind, double price) {
        Robot robot;
        switch (robotType){
            case "MaleRobot":
                robot = new MaleRobot(robotName,robotKind,price);
                break;
            case "FemaleRobot":
                robot = new FemaleRobot(robotName, robotKind, price);
                break;
            default:
                throw new IllegalArgumentException(INVALID_ROBOT_TYPE);
        }
        for (Service service : services) {
            if (service.getName().equals(serviceName)){
                String serviceType = service.getClass().getSimpleName();
                if (isSuitableServiceForRobot(serviceType, robotType)){
                    service.addRobot(robot);
                    return String.format(SUCCESSFULLY_ADDED_ROBOT_IN_SERVICE, robotType, serviceName);
                }else {
                    return String.format(UNSUITABLE_SERVICE);
                }
            }
        }

        return null;
    }
    private boolean isSuitableServiceForRobot(String serviceType, String robotType){
        if (robotType.equals("FemaleRobot") && serviceType.equals("SecondaryService")){
            return true;
        }
        if (robotType.equals("MaleRobot") && serviceType.equals("MainService")){
            return true;
        }
        return false;
    }
    @Override
    public String feedingRobot(String serviceName) {
        int robotCounter = 0;
        for (Service service : services) {
            if (service.getName().equals(serviceName)){
                service.feeding();
               robotCounter = service.getRobots().size();
            }
        }
        return String.format(FEEDING_ROBOT, robotCounter);
    }

    @Override
    public String sumOfAll(String serviceName) {
        Service service = services.stream().filter(s-> s.getName().equals(serviceName)).findFirst().orElse(null);
        double sumOfSupplement = service.getSupplements().stream().mapToDouble(Supplement::getPrice).sum();
        double sumOfRobots = service.getRobots().stream().mapToDouble(Robot::getPrice).sum();

        return String.format(VALUE_SERVICE, serviceName, sumOfRobots + sumOfSupplement);
    }

    @Override
    public String getStatistics() {
        return services.stream()
                .map(Service::getStatistics)
                .collect(Collectors.joining(System.lineSeparator())).trim();
    }
}
