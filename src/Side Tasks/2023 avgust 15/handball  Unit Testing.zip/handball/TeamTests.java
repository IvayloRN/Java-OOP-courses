package handball;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class TeamTests {
    private static final String DEFAULT_TEAM_NAME = "Spartak";
    private static final int DEFAULT_CAPACITY = 2;
    private Team team;
    private HandballPlayer pesho;
    private HandballPlayer tosho;

    @Before
    public void setUp(){
        team = new Team(DEFAULT_TEAM_NAME, DEFAULT_CAPACITY);
        pesho = new HandballPlayer("Pesho");
        tosho = new HandballPlayer("Tosho");
    }
    @Test(expected = NullPointerException.class)
    public void test_setName_Throws_if_Name_is_Null(){
        Team team = new Team(null, 2);

    }

    @Test(expected = NullPointerException.class)
    public void test_setName_Throws_if_Name_is_Empty(){
        Team team1 = new Team("   ", 1);
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_setPosition_Throws_if_Less_then_Zero(){
        Team team1 = new Team("Real", -1);
    }
    @Test
    public void test_getCount_Should_Return_Size(){
        team.add(pesho);
        assertEquals(1, team.getCount());
        team.add(tosho);
        assertEquals(2, team.getCount());
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_Add_Throws_if_Cat_added_on_Fullhouse(){
        Team team1 = new Team("Levski", 1);
        team1.add(pesho);
        team1.add(tosho);
    }
    @Test
    public void test_remove_Should_Remove_Player(){
        team.add(pesho);
        team.add(tosho);
        assertEquals(2, team.getCount());
        team.remove("Pesho");
        assertEquals(1, team.getCount());

    }
    @Test(expected = IllegalArgumentException.class)
    public void test_Remove_Throws_if_No_Such_Player(){
        team.add(pesho);
        team.remove("GOSHO");
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_playerForAnotherTeam_Throws_If_No_Such_Player(){
        team.add(pesho);
        team.playerForAnotherTeam("Gosho");
    }
    @Test
    public void test_PlayerForAnotherTeam_Should_return_Player(){
        team.add(pesho);
        team.add(tosho);
        team.playerForAnotherTeam("Pesho");
        assertFalse(pesho.isActive());
    }
    @Test
    public void test_getStatistics_Should_Return_Right_String(){
        String expected = "The player Pesho is in the team Spartak.";
        team.add(pesho);
        assertEquals(expected, team.getStatistics());
    }
    @Test
    public void test_getName_Returns_Name(){
        team.add(pesho);
        assertEquals("Spartak", team.getName());
    }
    @Test
    public void test_GetPosition_should_Return_Number_of_Positions(){

        assertEquals(2, team.getPosition());
    }
    @Test
    public void test_setName_Returns_Name(){
        Team team = new Team("Real", 1);
        assertEquals("Real", team.getName());
    }
    @Test
    public void test_setPosition_Should_Set_position(){
        Team team1 = new Team("Real", 5);
        assertEquals(5, team1.getPosition());
    }
    @Test
    public void test_Constructor1(){
        assertEquals(team.getName(), "Spartak");
        assertEquals(team.getPosition(), 2);
        assertEquals(team.getCount(), 0);
    }


}
