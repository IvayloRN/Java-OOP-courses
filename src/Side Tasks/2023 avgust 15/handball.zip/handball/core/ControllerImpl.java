package handball.core;

import handball.entities.equipment.ElbowPad;
import handball.entities.equipment.Equipment;
import handball.entities.equipment.Kneepad;
import handball.entities.gameplay.Gameplay;
import handball.entities.gameplay.Indoor;
import handball.entities.gameplay.Outdoor;
import handball.entities.team.Bulgaria;
import handball.entities.team.Germany;
import handball.entities.team.Team;
import handball.repositories.EquipmentRepository;
import handball.repositories.Repository;

import java.util.*;
import java.util.stream.Collectors;

import static handball.common.ConstantMessages.*;
import static handball.common.ExceptionMessages.*;

public class ControllerImpl implements Controller{
    private Repository equipments;
    private Map<String, Gameplay> gameplays;

    public ControllerImpl() {
        this.equipments = new EquipmentRepository();
        this.gameplays = new LinkedHashMap<>();
    }

    @Override
    public String addGameplay(String gameplayType, String gameplayName) {
        Gameplay gameplay;
        switch (gameplayType){
            case "Outdoor":
                gameplay = new Outdoor(gameplayName);
                break;
            case "Indoor":
                gameplay = new Indoor(gameplayName);
                break;
            default:
                throw new NullPointerException(INVALID_GAMEPLAY_TYPE);
        }
        gameplays.put(gameplayName, gameplay);
        return String.format(SUCCESSFULLY_ADDED_GAMEPLAY_TYPE, gameplayType);
    }

    @Override
    public String addEquipment(String equipmentType) {
        Equipment equipment;
        switch (equipmentType){
            case "Kneepad":
                equipment = new Kneepad();
                break;
            case "ElbowPad":
                equipment = new ElbowPad();
                break;
            default:
                throw new IllegalArgumentException(INVALID_EQUIPMENT_TYPE);
        }
        equipments.add(equipment);

        return String.format(SUCCESSFULLY_ADDED_EQUIPMENT_TYPE, equipmentType);
    }

    @Override
    public String equipmentRequirement(String gameplayName, String equipmentType) {
        Equipment equipment = equipments.findByType(equipmentType);
        if (equipment == null){
            throw new IllegalArgumentException(String.format(NO_EQUIPMENT_FOUND, equipmentType));
        }
        gameplays.get(gameplayName).addEquipment(equipment);
        equipments.remove(equipment);
        return String.format(SUCCESSFULLY_ADDED_EQUIPMENT_IN_GAMEPLAY, equipmentType, gameplayName);
    }

    @Override
    public String addTeam(String gameplayName, String teamType, String teamName, String country, int advantage) {
        String gameplayType = gameplays.get(gameplayName).getClass().getSimpleName();
        Team team;
        switch (teamType){
            case "Bulgaria":
                team = new Bulgaria(teamName, country, advantage);
                break;
            case "Germany":
                team = new Germany(teamName, country, advantage);
                break;
            default:
                throw new IllegalArgumentException(INVALID_TEAM_TYPE);
        }
        if (!isSuitable(gameplayType, teamType)){
            return GAMEPLAY_NOT_SUITABLE;
        }
            gameplays.get(gameplayName).addTeam(team);
            return String.format(SUCCESSFULLY_ADDED_TEAM_IN_GAMEPLAY, teamType, gameplayName);
    }

    @Override

    public String playInGameplay(String gameplayName) {
        gameplays.get(gameplayName).teamsInGameplay();
        return String.format(TEAMS_PLAYED, gameplays.get(gameplayName).getTeam().size());
    }
    @Override
    public String percentAdvantage(String gameplayName) {
        Gameplay gameplay = gameplays.get(gameplayName);
        int totalAdvantage = gameplay.getTeam().stream().mapToInt(Team::getAdvantage).sum();

        return String.format(ADVANTAGE_GAMEPLAY,gameplayName, totalAdvantage);
    }
    @Override
    public String getStatistics() {
        return gameplays.values().stream().map(Gameplay::toString).collect(Collectors.joining(System.lineSeparator()));
    }






    private boolean isSuitable(String gameplayType, String teamName){
        if (teamName.equals("Germany") && gameplayType.equals("Indoor")){
            return true;
        }
        if (teamName.equals("Bulgaria") && gameplayType.equals("Outdoor")) {
            return true;
        }
        return false;
    }
}
