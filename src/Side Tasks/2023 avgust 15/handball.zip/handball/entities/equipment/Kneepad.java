package handball.entities.equipment;

import java.util.Scanner;

public class Kneepad extends BaseEquipment{
    private static final int INITIAL_PROTECTION = 120;
    private static final double DEFAULT_PRICE = 15;

    public Kneepad() {
        super(INITIAL_PROTECTION, DEFAULT_PRICE);
    }
}
//It has 120 protection, and its price is 15.