package handball.entities.team;

import java.util.Scanner;

public class Germany extends BaseTeam{           //    I can only play Indoor!
    public Germany(String name, String country, int advantage) {
        super(name, country, advantage);
    }

    @Override
    public void play() {
        setAdvantage(getAdvantage() + 145);
    }
}
