package handball.entities.team;

import java.util.Scanner;

public class Bulgaria extends BaseTeam{     //  I can only play Outdoor!

    public Bulgaria(String name, String country, int advantage) {
        super(name, country, advantage);

    }

    @Override
    public void play() {
        setAdvantage(getAdvantage() + 115);
    }
}
