package climbers.repositories;

import climbers.models.climber.Climber;

import java.util.*;

public class ClimberRepository implements Repository<Climber>{
    private Map<String, Climber> climbers;

    public ClimberRepository() {
        climbers = new LinkedHashMap<>();
    }

    @Override
    public Collection<Climber> getCollection() {
        return Collections.unmodifiableCollection(climbers.values());
    }

    @Override
    public void add(Climber climber) {
        climbers.put(climber.getName(), climber);

    }

    @Override
    public boolean remove(Climber entity) {
        return climbers.remove(entity.getName(), entity);
    }

    @Override
    public Climber byName(String name) {
        return climbers.values().stream().filter(e-> e.getName().equals(name)).findFirst().orElse(null);
    }
}
