package climbers.repositories;

import climbers.models.mountain.Mountain;

import java.util.*;

public class MountainRepository implements Repository<Mountain>{
    private Map<String, Mountain> mountainsRepo;

    public MountainRepository() {
        this.mountainsRepo = new LinkedHashMap<>();
    }

    @Override
    public Collection<Mountain> getCollection() {
        return Collections.unmodifiableCollection(mountainsRepo.values());
    }

    @Override
    public void add(Mountain entity) {
        mountainsRepo.put(entity.getName(), entity);

    }

    @Override
    public boolean remove(Mountain entity) {
        return mountainsRepo.remove(entity.getName(), entity);
    }

    @Override
    public Mountain byName(String name) {
        return mountainsRepo.values().stream().filter(m-> m.getName().equals(name)).findFirst().orElse(null);
    }
}
