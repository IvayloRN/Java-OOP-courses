package climbers.models.climbing;

import climbers.models.climber.Climber;
import climbers.models.mountain.Mountain;

import java.util.Collection;
import java.util.Iterator;
import java.util.Scanner;

public class ClimbingImpl implements Climbing{
    @Override
    public void conqueringPeaks(Mountain mountain, Collection<Climber> climbers) {
        Collection<String> mountainTops = mountain.getPeaksList();

        for (Climber climber : climbers) {
            while (climber.canClimb() && mountainTops.iterator().hasNext()){
                climber.climb();
                String currentTop = mountainTops.iterator().next();
                climber.getRoster().getPeaks().add(currentTop);
                mountainTops.remove(currentTop);
            }
        }


    }
}
