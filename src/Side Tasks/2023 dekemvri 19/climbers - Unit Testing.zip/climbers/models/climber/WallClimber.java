package climbers.models.climber;

import java.util.Scanner;

public class WallClimber extends BaseClimber{
    private static final double INITIAL_STRENGHT = 90;

    public WallClimber(String name) {
        super(name, INITIAL_STRENGHT);
    }

    @Override
    public void climb() {
        setStrength(getStrength()- 30);
    }
}
