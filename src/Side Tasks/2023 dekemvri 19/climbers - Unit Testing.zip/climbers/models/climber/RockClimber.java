package climbers.models.climber;

import java.util.Scanner;

public class RockClimber extends BaseClimber{
    private static final double INITIAL_STRENGHT = 120;

    public RockClimber(String name) {
        super(name, INITIAL_STRENGHT);
    }

    @Override
    public void climb() {
        setStrength(getStrength() - 60);
    }
}
