package stuntClimb;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ClimbingTests {
    Climbing climbing;
    RockClimber pesho;
    RockClimber tosho;


    @Before
    public void setUp(){
        climbing = new Climbing("Rila", 2);
        pesho = new RockClimber("Pesho", 10);
        tosho = new RockClimber("Tosho", 20);
    }

    @Test(expected = NullPointerException.class)
    public void test_setName_Should_Throw_if_Name_is_Null(){
        Climbing climb = new Climbing(null, 2);
    }
    @Test(expected = NullPointerException.class)
    public void test_setName_Should_Throw_if_Name_is_Empty(){
        Climbing climb = new Climbing("    ", 2);
    }
    @Test
    public void test_setName_Should_set_Name(){
        Climbing climbing = new Climbing("Pirin", 2);
        assertEquals("Pirin", climbing.getName());
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_setCapacity_Should_Throw_if_Capacity_Less_Then_Zero(){
        Climbing climbing = new Climbing("Rila", -1);
    }
    @Test
    public void test_removeClimber_Should_Return_True_if_Removed(){
        climbing.addRockClimber(pesho);
        assertTrue(climbing.removeRockClimber("Pesho"));

    }
    @Test
    public void test_removeClimber_Should_Return_False_if_not_Exist(){
        climbing.addRockClimber(pesho);
        assertFalse(climbing.removeRockClimber("Tosho"));
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_addRockClimber_Throws_if_No_Capacity(){
        Climbing climbing = new Climbing("Rila", 1);
        climbing.addRockClimber(pesho);
        climbing.addRockClimber(tosho);
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_addRockClimber_Throws_if_Climber_exists(){
        climbing.addRockClimber(pesho);
        climbing.addRockClimber(pesho);
    }
    @Test
    public void test_getCount_Check_if_itIS_Counting(){
        climbing.addRockClimber(pesho);
        assertEquals(1, climbing.getCount());
        climbing.addRockClimber(tosho);
        assertEquals(2, climbing.getCount());
    }





}
