package week1ABSTRACTIONS._4_TrafficLights;

import java.util.Scanner;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW;

}
