import solidLab.p02_OpenClosedPrinciple.p01_FileStream.File;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        Class reflection = Reflection.class;

        Class<Reflection> clazz = Reflection.class;

        System.out.println(clazz);
        System.out.println(clazz.getSuperclass());

        Class<?>[] interfaces = clazz.getInterfaces();

        for (Class<?> i : interfaces) {
            System.out.println(i);
        }

        Object reflectionObj = reflection.getDeclaredConstructor().newInstance();
        System.out.println(reflectionObj);
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            System.out.println(field);
        }
        Field webadressss = clazz.getDeclaredField("webAddress");
        System.out.println(webadressss);
        webadressss.setAccessible(true);



        //SET

        Constructor<Reflection> constructor = clazz.getDeclaredConstructor();
        Reflection reflection1 = constructor.newInstance();

        webadressss.set(reflection1, "www.testvam.com");
        System.out.println(reflection1);


        //GET
        System.out.println(webadressss.get(reflection1));

    }


}
