

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchFieldException {

        Class<Reflection> clazz = Reflection.class;
        Method[] methods = clazz.getDeclaredMethods();

        Arrays.stream(methods).filter(e-> !e.getName().equals("toString"))
                .sorted(Comparator.comparing(Method::getName))
                .forEach(method -> System.out.println(printMethods(method)));


    }
    private static String printMethods(Method m){
        if (m.getName().startsWith("get")){
            return m.getName() +  " will return class " + m.getReturnType().getName();
        }
        return m.getName() +  " and will set field of class " + m.getParameterTypes()[0].getName();
    }


}
