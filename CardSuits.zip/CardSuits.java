package week1ABSTRACTIONS._1_CardSuit;

import java.util.Scanner;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
//CLUBS, DIAMONDS, HEARTS, SPADES